import gauss_reduced_ref

a=gauss_reduced_ref.three_terms([[2,5,10,12],[3,9,2,4],[4,-3,2,-1]])
print(a)